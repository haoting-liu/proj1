#include <string>
#include <iostream>
using namespace std;

int main(){
int count = 0, count2 = 0, mark = 0, sign = 0, semi = 0, start = 0;
string url = "", protocol = "", domain = "", filePath = "", parameter = "";
bool p = false, d = false, po = false, f = false, pa = false, questionMark = false;

cout << "Enter the web URL:";
cin >> url;
cout << "then the output should look like the followings:\n";
//protocols
while(url.at(count) != ':'){
count++;
}
protocol = url.substr(0, count);
if(protocol.compare("http") == 0 || protocol.compare("https") == 0 ||
protocol.compare("ftp") == 0 || protocol.compare("ftps") == 0){
cout << "Protocol: " + protocol << endl;
}
else
cout << protocol + " is not a valid protocol.\n";
//domain
count = count + 3;
start = count;
while(count < url.length()){
if(url.at(count) == '.')
  count2++;
if(count2 == 1)
mark = count + 1;
if(url.at(count) == ':'){
semi = count;
sign = count;
}
else if(url.at(count) == '/'){
sign = count;
break;
}
count++;
}
if(count2 == 2 && url.substr(mark + 1, 3).compare("com") == 0 || url.substr(mark + 1, 3).compare("net") == 0 ||
url.substr(mark + 1, 3).compare("edu") == 0 || url.substr(mark + 1, 3).compare("biz") == 0 ||
url.substr(mark + 1, 3).compare("gov") == 0)
d = true;
if(semi != 0){
if(d == true)
domain = url.substr(start, semi - start);
else
domain = url.substr(mark + 1, semi - mark - 1);
}
else
if(d == true)
domain = url.substr(start, sign - start);
else
domain = url.substr(mark + 1, sign - mark - 1);
count2 = 0;
if(d == true)
cout << "Domain: " + domain << endl;
else
cout << domain + " is not a valid domain.\n";
//port
count = mark + 4;
sign = count;
int num = 0;
if(url.at(count) == ':'){
while(url.at(count) != '/'){
count2++;
count++;
}
num = stoi(url.substr(sign + 1, count2 - 1));
if(num >= 1 && num <= 65535)
po = true;
}
else{
po = true;
sign = -999;
}
if(po == true && sign != -999)
cout << "port: " + to_string(num) << endl;
else if(po == false)
cout << to_string(num) + " is not a valid port, port number must be between 1 and 65535\n";
//file path
sign = count;
while(count < url.length() - 1){
if(url.at(count) == '?'){
mark = count;
questionMark = true;
}
count++;
}
count = sign;
count2 = url.length() - 1;
if(url.at(mark) == '?'){
while(url.at(count) != '?'){
if(url.at(count + 1) == '.')
mark = count + 1;
count++;
}
}
else{
while(count < count2){
if(url.at(count + 1) == '.')
mark = count + 1;
count++;
}
}
if(url.at(sign) == '/')
if(url.substr(mark, 4) == ".html" || url.substr(mark, 4) == ".htm")
f = true;
filePath = url.substr(sign, count - sign);
if(f == true)
cout << "File path: " + filePath << endl;
else
cout << filePath + " is not a valid file path.\n";
//parameter
if(count < url.length()){
parameter = url.substr(count + 1, url.length());
if(url.at(count) == '?')
pa = true;
else if(questionMark == true)
cout << parameter + " is not a valid parameter.\n";
}
else
sign = -999;
if(pa == true && sign != -999)
cout << "Parameter: " + parameter << endl;
return 0;
}


