#include <bits/stdc++.h>
#include <cstdlib>
#include <string>
#include <iostream>
using namespace std;
int main(){
	string path = "";
	string syntax = "";
	cout << "enter the relative or absolute path: " << endl;
	cin >> path;
	syntax = "find " + path + " -type d 2>/dev/null | wc -l";
	cout << "The total number of directories in directory " + path + " is: " << endl; 		system(syntax.c_str());
	syntax = "ls -la " + path + " | egrep -c '^-'";
	cout << "The total number of files in directory " + path + " is: " << endl;			  		
	system(syntax.c_str());
	syntax = "du -sh --apparent-size 2>/dev/null " + path;
	cout << "The total number of bytes occupied by all files in directory " + path + " is: " << endl; 		
	system(syntax.c_str());
	return 0;
}
