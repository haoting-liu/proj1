#include <bits/stdc++.h>
#include <cstdlib>
#include <string>
#include <iostream>
using namespace std;
int main(){
	string msg = "";
	string command = "";
	string choice = "";
	cout << "Input goes over here: " << endl;
	getline(cin, msg);
	cout << "Choose one of the options over here(-d,-f,-b)";
	cin >> choice;
	if(choice == "-d"){
		command = "echo '" + msg + "' | grep -m 1 'directories'";
		system(command.c_str());
	}
	else if(choice == "-f"){
		command = "echo '" + msg + "' | grep -m 1 'files'";
		system(command.c_str());
	}
	else if(choice == "-b"){
		command = "echo '" + msg + "' | grep -m 1 'bytes'";
		system(command.c_str());
	}
	return 0;
}
